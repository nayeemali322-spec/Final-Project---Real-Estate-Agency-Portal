<?php include 'includes/header.php'; ?>
<h2>Welcome</h2>
<p>This is a starter Real Estate Agency.</p>
<p>In this Real Estate website you can register as a buyer, or renter. After registering, you can look for properties and inquire about them if you are interested.</p>

<div class="card">
    <h3> Roles</h3>
    <ul>
        <li>Agent: add and manage listings</li>
        <li>Buyer: browse properties and submit inquiries</li>
        <li>Renter: browse properties and submit inquiries</li>
    </ul>
</div>

<?php include 'includes/footer.php'; ?>