<?php
require_once __DIR__ . '/Database.php';

class RealEstateDatabase {
    private PDO $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->connect();
    }

    public function addUser(string $userName, string $contactInfo, string $passwordHash, string $userType): bool {
        // TODO: done
        // 1. Insert a new user into the Users table using a prepared statement.
        // 2. Return true if successful, false otherwise.
        $sql = "INSERT INTO Users (userName, contactInfo, passwordHash, userType)
                VALUES (:userName, :contactInfo, :passwordHash, :userType)";
        $stmt = $this->conn->prepare($sql);

        return $stmt->execute([
            ':userName' => $userName,
            ':contactInfo' => $contactInfo,
            ':passwordHash' => $passwordHash,
            ':userType' => $userType
        ]);
    }

    public function getUserByUsername(string $userName) {
        // Retrieve one user by username.
        $sql = "SELECT * FROM Users WHERE userName = :userName LIMIT 1";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([':userName' => $userName]);
        return $stmt->fetch();
    }

    public function addProperty(string $title, string $propertyType, string $address, string $city, float $price, string $status, int $agentId): bool {
        // TODO: Insert a new property into the Properties table.
        //done
        $sql = "INSERT INTO Properties(title, propertyType, address, city, price, status, agentId)
                VALUES(:title, :propertyType, :address, :city, :price, :status, :agentId)";
        $stmt = $this->conn->prepare($sql);

        return $stmt->execute([
            ':title' => $title,
            ':propertyType' => $propertyType,
            ':address' => $address,
            ':city' => $address,
            ':price' => $price,
            ':status' => $status,
            ':agentId' => $agentId
        ]);
    }

    public function getAllProperties(): array {
        // TODO: Optionally replace this with the PropertyListingView.
        $sql = "SELECT p.*, u.userName AS agentName
                FROM Properties p
                JOIN Users u ON p.agentId = u.userId
                ORDER BY p.propertyId DESC";
        $stmt = $this->conn->query($sql);
        return $stmt->fetchAll();
    }

    public function getPropertyById(int $propertyId) {
        $sql = "SELECT p.*, u.userName AS agentName
                FROM Properties p
                JOIN Users u ON p.agentId = u.userId
                WHERE p.propertyId = :propertyId";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([':propertyId' => $propertyId]);
        return $stmt->fetch();
    }

    public function addInquiry(int $userId, int $propertyId, string $message): bool {
        // TODO: Insert a new inquiry with the current date and time.
        //done
        $sql = "INSERT INTO Inquiries(userId, propertyId, message, createdAt)
            VALUES(:userId, :propertyId, :message, :createdAt)";
        $stmt = $this->conn->prepare($sql);

        return $stmt->execute([
            ':userId' => $userId, 
            ':propertyId' => $propertyId, 
            ':message' => $message, 
            ':createdAt' => date('Y-m-d H:i:s')
            ]);
    }

    public function getUserDetails(int $userId) {
        // TODO: Done
        // Expand this function so it returns the user plus their related
        // inquiries, favorites, or transactions.
        $sql = "SELECT * FROM Users WHERE userId = :userId";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([':userId' => $userId]);
        $user = $stmt->fetch();

        if(!$user){
            return null;
        }
        $sqlInquiries = "SELECT * FROM Inquiries where userId = :userId ORDER BY createdAt DESC";
        $stmt = $this->conn->prepare($sqlInquiries);
        $stmt -> execute([':userId' => $userId]);
        $user['inquiries'] = $stmt->fetchAll();

        return $user;
    }

    public function getPropertiesByCity(string $city): array {
        // TODO: Finish this function

        //done

        $sql = "SELECT p.*, u.userName AS agentName
                FROM Properties p
                JOIN Users u ON p.agentId = u.userId
                WHERE p.city = :city
                ORDER BY p.propertyId DESC";

        $stmt = $this->conn->prepare($sql);
        $stmt->execute([':city' => $city]);

        return $stmt->fetchAll();
    }
}
?>